//
//  ViewController.swift
//  ButtonKit Demo
//
//  Created by Tobbe on 2020-06-06.
//  Copyright © 2020 44. All rights reserved.
//

import UIKit
import ButtonKit

class ViewController: UIViewController {

    override func viewDidLoad() {
    
        super.viewDidLoad()
        
        let button = Button(width: 200, text: "Done", color: nil, style: nil, size: nil) {
            
            // code
        }
        
        button.center = CGPoint(x: view.bounds.midX, y: view.bounds.midY)
        button.autoresizingMask = [.flexibleLeftMargin, .flexibleRightMargin, .flexibleTopMargin, .flexibleBottomMargin]
        view.addSubview(button)
    }
}
